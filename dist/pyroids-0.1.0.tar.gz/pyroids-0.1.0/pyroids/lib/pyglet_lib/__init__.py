#! /usr/bin/env python

"""Initialisation file to recognise pyglet_lib as subpackage."""
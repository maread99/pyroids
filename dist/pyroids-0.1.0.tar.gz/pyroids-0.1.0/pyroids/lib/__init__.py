#! /usr/bin/env python

"""Initialisation file to recognise lib as subpackage."""